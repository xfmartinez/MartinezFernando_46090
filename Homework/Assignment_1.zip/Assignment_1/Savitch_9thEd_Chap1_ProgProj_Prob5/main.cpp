/* 
 * File:   main.cpp
 * Author:Fernando Martinez 
 * Created on June 25, 2015, 3:57 PM
 * Purpose: Be able o input any character on key board and have a Big C as and Output
 * 
 */

#include <iostream>

using namespace std; // std namespace -> iostream

//User Libraries

//Global Constants

//Function Prototypes 

//Exicution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables 
    char dis; 
    cout<<"Enter any character\n";
    cin>>dis;
    cout<<"  "<<dis<<" "<<dis<<" "<<dis<<endl;
    cout<<" "<<dis<<"    "<<dis<<endl;
    cout<<""<<dis<<endl; 
    cout<<""<<dis<<endl;
    cout<<""<<dis<<endl;
    cout<<""<<dis<<endl;
    cout<<""<<dis<<endl;
    cout<<" "<<dis<<"    "<<dis<<endl;
    cout<<"  "<<dis<<" "<<dis<<" "<<dis<<endl;
    
    

    return 0;
}

