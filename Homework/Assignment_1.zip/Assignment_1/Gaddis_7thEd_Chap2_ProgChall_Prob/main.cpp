/* 
 * File:   main.cpp
 * Author:Fernando Martinez 
 * Created on June 26, 2015, 12:59 PM
 * Purpose: Calculate The Miles per Gallon Of a car 
 */

#include <iostream>

using namespace std;
//User Libraries 

//Global Constants

//Function Prototypes

//Execution begins here!

int main(int argc, char** argv) {
    //Declare Variables
    float MiD, GgU; // Miles Driven, // Gallons of Gas when full.
    //OutPut Variables 
    cout<<"Enter Miles Driven\n";
    cin>>MiD;
    cout<<"Enter Gallons of Gas\n";
    cin>>GgU;
    cout<<"The Miles Per Gallon ="<<(MiD/GgU)<<endl;
    //Exit Stage Right!!
    

    return 0;
}

