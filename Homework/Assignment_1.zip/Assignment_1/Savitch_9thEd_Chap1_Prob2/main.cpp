/* 
 * File:   main.cpp
 * Author: Fernando Martinez 
 * Created on June 23, 2015, 8:54 PM
 * Purpose:Make a logo 
 */

#include <iostream> //File I/O

using namespace std; //std namespace -> iostream 
//User Libraries 
//Global Constants 
//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    cout<<"****************************************************\n";
    cout<<"        C C C                S S S S      !!        \n";
    cout<<"       C     C              S       S     !!        \n";
    cout<<"      C                    S              !!        \n";
    cout<<"     C                      S             !!        \n";
    cout<<"     C                       S S S S      !!        \n";
    cout<<"     C                              S     !!        \n";
    cout<<"      C                              S    !!        \n";
    cout<<"       C     C              S         S             \n";
    cout<<"        C C C                 S S S S     00        \n";
    cout<<"******************************************************\n";
    
    cout<<"Computer Science is Cool Stuff!!!\n";

    return 0;
}

